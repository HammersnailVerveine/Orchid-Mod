namespace OrchidMod.Alchemist
{
    public enum AlchemistElement : int
    {
		NULL = 0,
		WATER = 1,
		FIRE = 2,
		NATURE = 3,
		AIR = 4,
		LIGHT = 5,
		DARK = 6
    }
}  