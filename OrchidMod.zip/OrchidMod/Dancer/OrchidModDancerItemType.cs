﻿namespace OrchidMod.Dancer
{
	public enum OrchidModDancerItemType : byte
	{
		NULL,
		IMPACT,
		PHASE,
		MOMENTUM
	}
}
